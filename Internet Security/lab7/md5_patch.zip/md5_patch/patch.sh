#!/bin/sh

sudo cp ./lib/* /lib/
sudo cp ./md5collgen /usr/bin/
